#!/usr/bin/env bash
# Script for OCI Data Center Employee Onboarding on macOS
# Version: 0.2.3 (Updated for Bash 3.2.57 compatibility)
# Prerequisites: macOS with admin privileges, no active VPN connection.
# Target Bash Version: 3.2.57(1)-release (macOS default)

set -Eeuo pipefail

# Constants (Reusable across wrappers)
readonly SCRIPT_NAME="$(basename "$0")"
readonly LOG_FILE="/tmp/${SCRIPT_NAME}.log"
readonly JSON_SUMMARY_FILE="/tmp/${SCRIPT_NAME}_summary.json"
readonly MAX_RETRIES=3
readonly RETRY_SLEEP=5
readonly WAIT_TIMEOUT=60
readonly WAIT_INTERVAL=5
readonly PASSWORD_AGE_LIMIT=$((12 * 3600))
readonly TOOLS_DIR="$HOME/phx-gov-tools"
readonly PYTHON_VENV="$TOOLS_DIR/venv"
readonly GIT_REPO="ssh://git@bitbucket.oci.oraclecorp.com:7999/~jboydsto/phx-gov-tools.git"
readonly BITBUCKET_URL="https://bitbucket.oci.oraclecorp.com/plugins/servlet/ssh/account/keys"
readonly SSH_HOST="operator-access-token.svc.ad1.us-gov-phoenix-3"

# Global Variables (Reusable across functions and wrappers)
DRY_RUN=false
INTERACTIVE=true  # Default to interactive mode
LOG_LEVEL="INFO"
SUMMARY_JSON="{}"
USERNAME=""
GUID=""
SSH_KEY_SETUP_DONE=false

# Logging function with levels and timestamps
log() {
    local level="$1"
    local message="$2"
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    case "$level" in
        "ERROR") echo -e "\033[31m[$timestamp] [$level] $message\033[0m" | tee -a "$LOG_FILE" >&2 ;;
        "WARN") echo -e "\033[33m[$timestamp] [$level] $message\033[0m" | tee -a "$LOG_FILE" >&2 ;;
        *) echo "[$timestamp] [$level] $message" | tee -a "$LOG_FILE" >&2 ;;
    esac
    if [[ "$level" == "ERROR" ]]; then
        exit 1
    fi
}

# Update summary JSON for reporting
update_summary() {
    local step="$1"
    local status="$2"
    local message="$3"
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    if command -v jq >/dev/null 2>&1; then
        SUMMARY_JSON=$(echo "$SUMMARY_JSON" | jq -c --arg step "$step" --arg status "$status" --arg msg "$message" --arg ts "$timestamp" '. + {($step): {"status": $status, "message": $msg, "timestamp": $ts}}')
    else
        log "WARN" "jq not installed, appending to summary manually for $step"
        SUMMARY_JSON=$(printf '%s\n' "$SUMMARY_JSON" | sed 's/}/, "'"$step"'": {"status": "'"$status"'", "message": "'"$message"'", "timestamp": "'"$timestamp"'"} }')
    fi
}

# Usage information
usage() {
    cat <<EOF
Usage: $SCRIPT_NAME [options] [username] [guid]
Automates OCI data center employee onboarding on macOS.
Options:
  -d, --dry-run         Simulate actions without changes
  -n, --non-interactive Disable interactive prompts (for CI/CD)
  -h, --help            Display this help message
Example:
  ./$SCRIPT_NAME -d user@example.com 12345-guid
EOF
    exit 0
}

# Parse command-line arguments
parse_args() {
    while getopts "dnh" opt; do
        case "$opt" in
            d) DRY_RUN=true ;;
            n) INTERACTIVE=false ;;
            h) usage ;;
            *) usage ;;
        esac
    done
    shift $((OPTIND - 1))
    if [[ $# -gt 0 ]]; then
        USERNAME="$1"
        shift
    fi
    if [[ $# -gt 0 ]]; then
        GUID="$1"
    fi
}

# Prompt user for input (always prompt if interactive mode is true)
prompt_user() {
    local prompt="$1"
    local default="$2"
    local response=""
    if [[ "$INTERACTIVE" == true ]]; then
        read -p "$prompt [$default]: " response
        echo "${response:-$default}"
    else
        log "INFO" "Non-interactive mode: Using default '$default' for '$prompt'"
        echo "$default"
    fi
}

# Retry helper for eventual consistency
retry() {
    local max_attempts="$1"
    local sleep_seconds="$2"
    shift 2
    local attempt=1
    while [[ $attempt -le $max_attempts ]]; do
        log "INFO" "Attempt $attempt of $max_attempts: $*"
        if "$@"; then
            log "INFO" "Command succeeded: $*"
            return 0
        fi
        log "WARN" "Attempt $attempt failed: $*"
        [[ $attempt -eq $max_attempts ]] && { log "ERROR" "Max retries reached for: $*"; return 1; }
        sleep "$sleep_seconds"
        ((attempt++))
    done
    return 1
}

# Wait until a condition is met
wait_until() {
    local timeout="$1"
    local interval="$2"
    shift 2
    local start_time=$(date +%s)
    while true; do
        if "$@"; then
            log "INFO" "Condition met: $*"
            return 0
        fi
        local current_time=$(date +%s)
        if [[ $((current_time - start_time)) -ge $timeout ]]; then
            log "ERROR" "Timeout reached waiting for: $*"
            return 1
        fi
        log "INFO" "Waiting for condition: $*"
        sleep "$interval"
    done
}

# Generic function to check if a step is done and prompt for overwrite
check_and_prompt_overwrite() {
    local check_cmd="$1"
    local step_name="$2"
    if eval "$check_cmd"; then
        log "INFO" "$step_name already completed."
        if [[ "$INTERACTIVE" == true ]]; then
            local overwrite=$(prompt_user "Do you want to overwrite $step_name? (y/n)" "n")
            if [[ "$overwrite" =~ ^[Yy]$ ]]; then
                log "INFO" "User chose to overwrite $step_name."
                return 0 # Signal to proceed with overwrite (success)
            else
                log "INFO" "User chose not to overwrite $step_name."
                return 1 # Signal to skip the step (failure)
            fi
        else
            return 1 # Non-interactive mode skips overwrite (failure)
        fi
    else
        log "INFO" "$step_name not yet completed."
        return 0 # Proceed with step (success)
    fi
}

# Ensure directory exists with correct permissions
ensure_directory() {
    local dir_path="$1"
    local perms="$2"
    log "INFO" "Checking directory: $dir_path"
    if [[ -d "$dir_path" ]]; then
        log "INFO" "Directory $dir_path exists"
        local current_perms=$(stat -f "%Sp" "$dir_path" | cut -c 3-)
        if [[ "$current_perms" != "$perms" ]]; then
            log "INFO" "Fixing permissions for $dir_path to $perms"
            [[ "$DRY_RUN" == false ]] && chmod "$perms" "$dir_path" || log "INFO" "[DRY RUN] Would set permissions on $dir_path"
        fi
    else
        log "INFO" "Creating directory $dir_path with permissions $perms"
        if [[ "$DRY_RUN" == false ]]; then
            umask 077
            mkdir -p "$dir_path" || log "ERROR" "Failed to create directory $dir_path"
            chmod "$perms" "$dir_path" || log "ERROR" "Failed to set permissions on $dir_path"
        else
            log "INFO" "[DRY RUN] Would create directory $dir_path"
        fi
    fi
    update_summary "ensure_directory_$dir_path" "PASS" "Directory $dir_path ensured"
    return 0
}

# Setup SSH key for Bitbucket access
setup_ssh_key_for_bitbucket() {
    local step_name="SSH Key Setup for Bitbucket"
    if check_and_prompt_overwrite "[[ -f \"$HOME/.ssh/id_ed25519\" ]]" "$step_name"; then
        log "INFO" "Checking SSH key setup for Bitbucket access"
        if [[ "$DRY_RUN" == false ]]; then
            local ssh_key_path="$HOME/.ssh/id_ed25519"
            local ssh_pub_key_path="$ssh_key_path.pub"
            if [[ -f "$ssh_key_path" ]]; then
                log "INFO" "SSH key found at $ssh_key_path, checking if uploaded to Bitbucket"
                local uploaded=$(prompt_user "Have you uploaded your SSH key to Bitbucket? (y/n)" "n")
                if [[ "$uploaded" =~ ^[Yy]$ ]]; then
                    log "INFO" "User confirmed SSH key is uploaded"
                    SSH_KEY_SETUP_DONE=true
                    update_summary "ssh_key_setup" "PASS" "SSH key already uploaded"
                    return 0
                fi
            else
                log "INFO" "No SSH key found at $ssh_key_path, generating a new one"
                local generate=$(prompt_user "Generate a new SSH key for Bitbucket access? (y/n)" "n")
                if [[ "$generate" =~ ^[Yy]$ ]]; then
                    ssh-keygen -t ed25519 -C "$USERNAME" -f "$ssh_key_path" -N "" || log "ERROR" "Failed to generate SSH key"
                    log "INFO" "SSH key generated at $ssh_key_path"
                else
                    log "ERROR" "User declined to generate SSH key"
                    update_summary "ssh_key_setup" "FAIL" "User declined to generate SSH key"
                    return 1
                fi
            fi
            if [[ -f "$ssh_pub_key_path" ]]; then
                log "INFO" "Displaying your public SSH key for copying:"
                echo "----- BEGIN PUBLIC SSH KEY -----"
                cat "$ssh_pub_key_path"
                echo "----- END PUBLIC SSH KEY -----"
                echo "Please copy the above public key for uploading to Bitbucket."
            else
                log "ERROR" "Public SSH key not found at $ssh_pub_key_path"
                update_summary "ssh_key_setup" "FAIL" "Public SSH key not found"
                return 1
            fi
            local vpn_connected=$(prompt_user "Are you connected to the OCNA VPN? (y/n)" "n")
            if [[ "$vpn_connected" =~ ^[Yy]$ ]]; then
                log "INFO" "User confirmed connection to OCNA VPN"
                log "INFO" "Opening browser to Bitbucket for SSH key upload"
                open "$BITBUCKET_URL" || log "WARN" "Failed to open browser, visit $BITBUCKET_URL to upload your SSH key"
                local uploaded_confirm=$(prompt_user "Have you uploaded your SSH key to Bitbucket? (y/n)" "n")
                if [[ "$uploaded_confirm" =~ ^[Yy]$ ]]; then
                    log "INFO" "User confirmed SSH key uploaded"
                    SSH_KEY_SETUP_DONE=true
                    update_summary "ssh_key_setup" "PASS" "SSH key uploaded to Bitbucket"
                    return 0
                else
                    log "ERROR" "User did not upload SSH key to Bitbucket"
                    update_summary "ssh_key_setup" "FAIL" "User did not upload SSH key"
                    return 1
                fi
            else
                log "ERROR" "User is not connected to OCNA VPN. Please connect and rerun the script."
                update_summary "ssh_key_setup" "FAIL" "Not connected to OCNA VPN"
                return 1
            fi
        else
            log "INFO" "[DRY RUN] Would prompt for SSH key setup"
            update_summary "ssh_key_setup" "PASS" "[DRY RUN] SSH key setup simulated"
            return 0
        fi
    else
        update_summary "ssh_key_setup" "SKIPPED" "SSH key setup already completed, skipped by user"
        SSH_KEY_SETUP_DONE=true
        return 0
    fi
}

# Clone Python scripts repository
clone_python_scripts() {
    local step_name="Clone Python Scripts"
    if check_and_prompt_overwrite "[[ -d \"$TOOLS_DIR/.git\" ]]" "$step_name"; then
        log "INFO" "Cloning git repository for Python scripts into $TOOLS_DIR"
        if [[ -d "$TOOLS_DIR/.git" ]]; then
            log "INFO" "Git repository exists at $TOOLS_DIR, pulling latest changes"
            if [[ "$DRY_RUN" == false ]]; then
                cd "$TOOLS_DIR" && git pull || log "ERROR" "Failed to pull changes in $TOOLS_DIR"
            else
                log "INFO" "[DRY RUN] Would pull changes in $TOOLS_DIR"
            fi
        else
            log "INFO" "Cloning repository into $TOOLS_DIR"
            if [[ "$DRY_RUN" == false ]]; then
                ensure_directory "$TOOLS_DIR" "0700"
                setup_ssh_key_for_bitbucket
                git clone "$GIT_REPO" "$TOOLS_DIR" || log "ERROR" "Failed to clone repository into $TOOLS_DIR"
            else
                log "INFO" "[DRY RUN] Would clone repository into $TOOLS_DIR"
            fi
        fi
        update_summary "clone_python_scripts" "PASS" "Git repository cloned or updated at $TOOLS_DIR"
    else
        update_summary "clone_python_scripts" "SKIPPED" "Python scripts already cloned, skipped by user"
    fi
    return 0
}

# Install Python virtual environment
install_python_venv() {
    local step_name="Python Virtual Environment Installation"
    local python_version="3.9"
    if check_and_prompt_overwrite "[[ -d \"$PYTHON_VENV\" ]]" "$step_name"; then
        log "INFO" "Installing Python $python_version to virtual environment in $PYTHON_VENV"
        if [[ -d "$PYTHON_VENV" ]]; then
            log "INFO" "Python venv already exists at $PYTHON_VENV"
            update_summary "install_python_venv" "PASS" "Python venv already exists at $PYTHON_VENV"
            return 0
        fi
        if [[ "$DRY_RUN" == false ]]; then
            ensure_directory "$TOOLS_DIR" "0700"
            if ! command -v python$python_version >/dev/null 2>&1; then
                log "INFO" "Installing Python $python_version via Homebrew"
                brew install "python@$python_version" || log "ERROR" "Failed to install Python $python_version"
            fi
            log "INFO" "Creating virtual environment in $PYTHON_VENV"
            python$python_version -m venv "$PYTHON_VENV" || log "ERROR" "Failed to create venv in $PYTHON_VENV"
            log "SUCCESS" "Python $python_version venv created at $PYTHON_VENV"
        else
            log "INFO" "[DRY RUN] Would install Python $python_version and create venv at $PYTHON_VENV"
        fi
        update_summary "install_python_venv" "PASS" "Python venv installed at $PYTHON_VENV"
    else
        update_summary "install_python_venv" "SKIPPED" "Python venv already exists, skipped by user"
    fi
    return 0
}

# Install Xcode Command Line Tools
install_xcode_tools() {
    local step_name="Xcode Command Line Tools Installation"
    if check_and_prompt_overwrite "xcode-select -p >/dev/null 2>&1" "$step_name"; then
        log "INFO" "Installing Xcode Command Line Tools"
        if xcode-select -p >/dev/null 2>&1; then
            log "INFO" "Xcode Command Line Tools already installed"
            update_summary "install_xcode_tools" "PASS" "Xcode tools already installed"
            return 0
        fi
        if [[ "$DRY_RUN" == false ]]; then
            log "INFO" "Triggering installation of Xcode Command Line Tools. A popup will appear."
            echo "Please follow these steps:"
            echo "1. A popup window will appear asking to install Xcode Command Line Tools."
            echo "2. Click 'Install' or 'Get Xcode' in the popup to allow the installation."
            echo "3. Wait for the installation to complete; this may take a few minutes."
            xcode-select --install || log "ERROR" "Failed to trigger installation of Xcode Command Line Tools"
            local installed=$(prompt_user "Have you completed the installation of Xcode Command Line Tools from the popup? (y/n)" "n")
            if [[ "$installed" =~ ^[Yy]$ ]]; then
                log "INFO" "User confirmed Xcode Command Line Tools installation"
                if xcode-select -p >/dev/null 2>&1; then
                    log "INFO" "Xcode Command Line Tools verified as installed"
                    update_summary "install_xcode_tools" "PASS" "Xcode tools installed"
                else
                    log "ERROR" "Xcode Command Line Tools installation could not be verified."
                    update_summary "install_xcode_tools" "FAIL" "Xcode tools installation not verified"
                    return 1
                fi
            else
                log "ERROR" "User did not confirm Xcode Command Line Tools installation"
                update_summary "install_xcode_tools" "FAIL" "Xcode tools installation not confirmed"
                return 1
            fi
        else
            log "INFO" "[DRY RUN] Would install Xcode Command Line Tools"
            update_summary "install_xcode_tools" "PASS" "[DRY RUN] Xcode tools installed"
        fi
    else
        update_summary "install_xcode_tools" "SKIPPED" "Xcode tools already installed, skipped by user"
    fi
    return 0
}

# Install Homebrew
install_homebrew() {
    local step_name="Homebrew Installation"
    if check_and_prompt_overwrite "command -v brew >/dev/null 2>&1" "$step_name"; then
        log "INFO" "Installing Homebrew"
        local brew_prefix=$(brew --prefix 2>/dev/null || echo "/opt/homebrew")
        local brew_bin="${brew_prefix}/bin"
        local brew="${brew_bin}/brew"
        if [[ ! -x "$brew" ]]; then
            if [[ "$DRY_RUN" == false ]]; then
                /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)" || log "ERROR" "Failed to install Homebrew"
            else
                log "INFO" "[DRY RUN] Would install Homebrew"
            fi
        fi
        local export_line="export PATH=\"${brew_bin}:\$PATH\""
        local files=("$HOME/.zprofile" "$HOME/.bash_profile")
        for f in "${files[@]}"; do
            [[ -f "$f" ]] || touch "$f"
            if ! grep -Fqs "$export_line" "$f"; then
                if [[ "$DRY_RUN" == false ]]; then
                    {
                        echo ""
                        echo "# Added by installer: Homebrew"
                        echo "$export_line"
                    } >> "$f"
                else
                    log "INFO" "[DRY RUN] Would update PATH in $f"
                fi
            fi
        done
        if [[ ":$PATH:" != _":${brew_bin}:"_ ]]; then
            export PATH="${brew_bin}:$PATH"
        fi
        update_summary "install_homebrew" "PASS" "Homebrew installed"
    else
        update_summary "install_homebrew" "SKIPPED" "Homebrew already installed, skipped by user"
    fi
    return 0
}

# Install jq
install_jq() {
    local step_name="jq Installation"
    if check_and_prompt_overwrite "command -v jq >/dev/null 2>&1" "$step_name"; then
        log "INFO" "Installing jq"
        if command -v jq >/dev/null 2>&1; then
            log "INFO" "jq already installed"
            update_summary "install_jq" "PASS" "jq already installed"
            return 0
        fi
        if [[ "$DRY_RUN" == false ]]; then
            brew install jq || log "ERROR" "Failed to install jq"
        else
            log "INFO" "[DRY RUN] Would install jq"
        fi
        update_summary "install_jq" "PASS" "jq installed"
    else
        update_summary "install_jq" "SKIPPED" "jq already installed, skipped by user"
    fi
    return 0
}

# Install OpenSC
install_opensc() {
    local step_name="OpenSC Installation"
    if check_and_prompt_overwrite "command -v opensc-tool >/dev/null 2>&1" "$step_name"; then
        log "INFO" "Installing OpenSC"
        if command -v opensc-tool >/dev/null 2>&1; then
            log "INFO" "OpenSC already installed"
            update_summary "install_opensc" "PASS" "OpenSC already installed"
        else
            if [[ "$DRY_RUN" == false ]]; then
                brew install opensc || log "ERROR" "Failed to install OpenSC"
                log "INFO" "OpenSC installed via Homebrew"
            else
                log "INFO" "[DRY RUN] Would install OpenSC"
            fi
            update_summary "install_opensc" "PASS" "OpenSC installed"
        fi
        if [[ "$DRY_RUN" == false ]]; then
            log "INFO" "Copying opensc-pkcs11.so to required locations"
            local opensc_version_dir=""
            if [[ -d "/opt/homebrew/Cellar/opensc" ]]; then
                opensc_version_dir=$(ls -d /opt/homebrew/Cellar/opensc/* | sort -V | tail -1)
                if [[ -z "$opensc_version_dir" ]]; then
                    log "ERROR" "Could not find OpenSC version directory in /opt/homebrew/Cellar/opensc"
                    update_summary "copy_opensc_pkcs11" "FAIL" "Failed to locate OpenSC version directory"
                    return 1
                fi
                log "INFO" "Found OpenSC version directory: $opensc_version_dir"
            else
                log "ERROR" "OpenSC not found in /opt/homebrew/Cellar/opensc"
                update_summary "copy_opensc_pkcs11" "FAIL" "OpenSC directory not found"
                return 1
            fi
            local source_file="$opensc_version_dir/lib/opensc-pkcs11.so"
            if [[ -f "$source_file" ]]; then
                log "INFO" "Copying opensc-pkcs11.so to /usr/local/lib/opensc-pkcs11.so (overwriting if exists)"
                sudo cp -f "$source_file" "/usr/local/lib/opensc-pkcs11.so" || log "ERROR" "Failed to copy opensc-pkcs11.so to /usr/local/lib/opensc-pkcs11.so"
                log "INFO" "Copying opensc-pkcs11.so to /Library/OpenSC/lib/opensc-pkcs11.so (overwriting if exists)"
                sudo mkdir -p "/Library/OpenSC/lib" || log "WARN" "Failed to create directory /Library/OpenSC/lib"
                sudo cp -f "$source_file" "/Library/OpenSC/lib/opensc-pkcs11.so" || log "ERROR" "Failed to copy opensc-pkcs11.so to /Library/OpenSC/lib/opensc-pkcs11.so"
                update_summary "copy_opensc_pkcs11" "PASS" "opensc-pkcs11.so copied to required locations"
            else
                log "ERROR" "opensc-pkcs11.so not found at $source_file"
                update_summary "copy_opensc_pkcs11" "FAIL" "Failed to locate opensc-pkcs11.so"
                return 1
            fi
        else
            log "INFO" "[DRY RUN] Would copy opensc-pkcs11.so to required locations"
            update_summary "copy_opensc_pkcs11" "PASS" "[DRY RUN] opensc-pkcs11.so copied"
        fi
    else
        update_summary "install_opensc" "SKIPPED" "OpenSC already installed, skipped by user"
    fi
    return 0
}

# Install YubiSwitch
install_yubiswitch() {
    local step_name="YubiSwitch Installation"
    if check_and_prompt_overwrite "[[ -d \"/Applications/YubiSwitch.app\" ]]" "$step_name"; then
        log "INFO" "Installing YubiSwitch"
        if [[ -d "/Applications/YubiSwitch.app" ]]; then
            log "INFO" "YubiSwitch already installed"
            update_summary "install_yubiswitch" "PASS" "YubiSwitch already installed"
            return 0
        fi
        if [[ "$DRY_RUN" == false ]]; then
            local dmg_file="/tmp/yubiswitch.dmg"
            curl -fsSL "https://github.com/pallotron/yubiswitch/releases/download/v0.18/yubiswitch_0.18.dmg" -o "$dmg_file" || log "ERROR" "Failed to download YubiSwitch"
            hdiutil attach "$dmg_file" -nobrowse -mountpoint /Volumes/YubiSwitch || log "ERROR" "Failed to mount YubiSwitch DMG"
            cp -R "/Volumes/YubiSwitch/YubiSwitch.app" "/Applications/" || log "ERROR" "Failed to install YubiSwitch"
            hdiutil detach /Volumes/YubiSwitch || log "WARN" "Failed to unmount YubiSwitch DMG"
            rm -f "$dmg_file"
        else
            log "INFO" "[DRY RUN] Would install YubiSwitch"
        fi
        update_summary "install_yubiswitch" "PASS" "YubiSwitch installed"
    else
        update_summary "install_yubiswitch" "SKIPPED" "YubiSwitch already installed, skipped by user"
    fi
    return 0
}

# Validate YubiKey configuration
validate_yubikey_config() {
    local step_name="YubiKey Configuration Validation"
    log "INFO" "Validating YubiKey configuration"
    local configured=$(prompt_user "Have you configured your YubiKey with YubiKey Manager as per https://confluence.oraclecorp.com/confluence/display/OCIID/Ordering+and+Activating+your+YubiKey+for+OCNA+and+OCI? (y/n)" "n")
    if [[ "$configured" =~ ^[Yy]$ ]]; then
        log "INFO" "User confirmed YubiKey configuration"
        update_summary "validate_yubikey_config" "PASS" "YubiKey configuration confirmed"
        return 0
    else
        log "ERROR" "User has not configured YubiKey"
        update_summary "validate_yubikey_config" "FAIL" "YubiKey not configured"
        return 1
    fi
}

# Install iTerm2
install_iterm2() {
    local step_name="iTerm2 Installation"
    if check_and_prompt_overwrite "[[ -d \"/Applications/iTerm.app\" ]]" "$step_name"; then
        log "INFO" "Installing iTerm2"
        if [[ -d "/Applications/iTerm.app" ]]; then
            log "INFO" "iTerm2 already installed"
            update_summary "install_iterm2" "PASS" "iTerm2 already installed"
            return 0
        fi
        if [[ "$DRY_RUN" == false ]]; then
            local open_browser=$(prompt_user "iTerm2 needs to be installed from https://iterm2.com. Open browser to download? (y/n)" "n")
            if [[ "$open_browser" =~ ^[Yy]$ ]]; then
                open "https://iterm2.com" || log "WARN" "Failed to open browser, download from https://iterm2.com"
                local installed=$(prompt_user "Have you installed iTerm2 to /Applications? (y/n)" "n")
                if [[ "$installed" =~ ^[Yy]$ ]]; then
                    log "INFO" "User confirmed iTerm2 installation"
                    update_summary "install_iterm2" "PASS" "iTerm2 installed"
                    return 0
                else
                    log "ERROR" "User did not install iTerm2"
                    update_summary "install_iterm2" "FAIL" "iTerm2 not installed"
                    return 1
                fi
            else
                log "ERROR" "User declined to download iTerm2"
                update_summary "install_iterm2" "FAIL" "User declined to download iTerm2"
                return 1
            fi
        else
            log "INFO" "[DRY RUN] Would install iTerm2"
        fi
        update_summary "install_iterm2" "PASS" "iTerm2 installed"
    else
        update_summary "install_iterm2" "SKIPPED" "iTerm2 already installed, skipped by user"
    fi
    return 0
}

# Enable TouchID for iTerm2
enable_touchid_iterm2() {
    local step_name="TouchID for iTerm2 Configuration"
    if check_and_prompt_overwrite "grep -q \"auth sufficient pam_tid.so\" /etc/pam.d/sudo 2>/dev/null" "$step_name"; then
        log "INFO" "Enabling TouchID for iTerm2 sudo"
        if grep -q "auth sufficient pam_tid.so" /etc/pam.d/sudo 2>/dev/null; then
            log "INFO" "TouchID already enabled in /etc/pam.d/sudo"
            update_summary "enable_touchid_iterm2" "PASS" "TouchID already enabled for sudo"
        else
            if [[ "$DRY_RUN" == false ]]; then
                log "INFO" "Adding TouchID configuration to /etc/pam.d/sudo (requires sudo password)"
                sudo sh -c 'echo "auth sufficient pam_tid.so" | cat - /etc/pam.d/sudo > /tmp/sudo_temp && mv /tmp/sudo_temp /etc/pam.d/sudo' || log "ERROR" "Failed to enable TouchID in /etc/pam.d/sudo"
                update_summary "enable_touchid_iterm2" "PASS" "TouchID enabled for sudo"
            else
                log "INFO" "[DRY RUN] Would enable TouchID in /etc/pam.d/sudo"
                update_summary "enable_touchid_iterm2" "PASS" "[DRY RUN] TouchID enabled for sudo"
            fi
        fi
        local updated=$(prompt_user "Have you updated iTerm2 Prefs -> Advanced -> 'Allow sessions to survive logging out and back in' to 'no'? (y/n)" "n")
        if [[ "$updated" =~ ^[Yy]$ ]]; then
            log "INFO" "User confirmed iTerm2 preference update"
        else
            log "WARN" "User did not update iTerm2 preferences"
            update_summary "enable_touchid_iterm2_prefs" "FAIL" "iTerm2 preferences not updated"
        fi
        update_summary "enable_touchid_iterm2_prefs" "PASS" "iTerm2 TouchID instructions provided"
    else
        update_summary "enable_touchid_iterm2" "SKIPPED" "TouchID for iTerm2 already configured, skipped by user"
    fi
    return 0
}

# Setup SSH configuration
setup_ssh_config() {
    local step_name="SSH Configuration Setup"
    local ssh_dir="$HOME/.ssh"
    local ssh_configs_dir="$ssh_dir/alt_ssh_configs"
    local ssh_config_file="$ssh_dir/config"
    ensure_directory "$ssh_dir" "0700"
    log "INFO" "Setting up SSH configuration"
    local vpn_connected=$(prompt_user "Are you connected to the OCNA VPN for Bitbucket access? (y/n)" "n")
    if [[ "$vpn_connected" =~ ^[Yy]$ ]]; then
        log "INFO" "User confirmed connection to OCNA VPN"
    else
        log "ERROR" "User is not connected to OCNA VPN. Please connect and rerun the script."
        update_summary "setup_ssh_config" "FAIL" "Not connected to OCNA VPN"
        return 1
    fi
    if [[ -d "$ssh_configs_dir/.git" ]]; then
        log "INFO" "Alternate SSH configs repository already cloned, pulling updates"
        if [[ "$DRY_RUN" == false ]]; then
            cd "$ssh_configs_dir" && git pull || log "ERROR" "Failed to pull alternate SSH configs updates"
        fi
    else
        log "INFO" "Cloning alternate SSH configs repository"
        if [[ "$DRY_RUN" == false ]]; then
            if [[ "$SSH_KEY_SETUP_DONE" != true ]]; then
                log "ERROR" "SSH key setup for Bitbucket not completed. Cannot clone repository."
                update_summary "setup_ssh_config" "FAIL" "SSH key setup not completed"
                return 1
            fi
            git clone "ssh://git@bitbucket.oci.oraclecorp.com:7999/gnoc/alt_ssh_configs.git" "$ssh_configs_dir" || log "ERROR" "Failed to clone alternate SSH configs repository"
        else
            log "INFO" "[DRY RUN] Would clone alternate SSH configs repository"
        fi
    fi
    if [[ -f "$ssh_config_file" ]] && grep -q "PKCS11Provider /Library/OpenSC/lib/opensc-pkcs11.so" "$ssh_config_file" 2>/dev/null; then
        log "INFO" "SSH config already includes PKCS11Provider"
    else
        log "INFO" "Adding PKCS11Provider to SSH config to prevent key fetch errors"
        if [[ "$DRY_RUN" == false ]]; then
            echo "PKCS11Provider /Library/OpenSC/lib/opensc-pkcs11.so" >> "$ssh_config_file"
            chmod 600 "$ssh_config_file" || log "WARN" "Failed to set permissions on SSH config"
        else
            log "INFO" "[DRY RUN] Would add PKCS11Provider to SSH config"
        fi
    fi
    if [[ -f "$ssh_config_file" ]] && grep -q "Include alt_ssh_configs/config" "$ssh_config_file" 2>/dev/null; then
        log "INFO" "SSH config already includes alt_ssh_configs/config"
    else
        log "INFO" "Adding Include directive to SSH config for alt_ssh_configs"
        if [[ "$DRY_RUN" == false ]]; then
            echo "Include alt_ssh_configs/config" >> "$ssh_config_file"
            chmod 600 "$ssh_config_file" || log "WARN" "Failed to set permissions on SSH config"
        else
            log "INFO" "[DRY RUN] Would add Include directive to SSH config for alt_ssh_configs"
        fi
    fi
    update_summary "setup_ssh_config" "PASS" "SSH configuration set up"
    return 0
}

# Install root certificates
install_root_certificates() {
    local step_name="Root Certificates Installation"
    local pki_dir="$HOME/sparta-pki"
    if check_and_prompt_overwrite "[[ -d \"$pki_dir/.git\" ]]" "$step_name"; then
        log "INFO" "Installing root certificates"
        if [[ -d "$pki_dir/.git" ]]; then
            log "INFO" "Sparta PKI repository already cloned, pulling updates"
            if [[ "$DRY_RUN" == false ]]; then
                cd "$pki_dir" && git pull || log "ERROR" "Failed to pull Sparta PKI updates"
            fi
        else
            log "INFO" "Cloning Sparta PKI repository"
            if [[ "$DRY_RUN" == false ]]; then
                setup_ssh_key_for_bitbucket
                git clone "ssh://git@bitbucket.us-ashburn-1.oci.oraclecorp.com:7999/secinf/sparta-pki.git" "$pki_dir" || log "ERROR" "Failed to clone Sparta PKI repository"
            else
                log "INFO" "[DRY RUN] Would clone Sparta PKI repository"
            fi
        fi
        if [[ "$DRY_RUN" == false ]]; then
            log "INFO" "Generating a mobileconfig file for root certificates to minimize password prompts"
            if [[ -f "$pki_dir/install-roots-osx.sh" ]]; then
                local python_script="$pki_dir/generate_mobileconfig.py"
                if [[ ! -f "$python_script" ]]; then
                    log "INFO" "Creating Python script to generate mobileconfig file"
                    cat <<EOF > "$python_script"
import re
import plistlib
import base64
from uuid import uuid4
from pathlib import Path

def extract_certificates_from_script(script_path):
    content = Path(script_path).read_text()
    pattern = re.compile(
        r"name='(.*?)'\s*data='(.*?)'\s*shasum='.*?'\s*unpack_cert",
        re.DOTALL
    )
    return pattern.findall(content)

def generate_mobileconfig(certs, output_path):
    profile = {
        "PayloadContent": [],
        "PayloadDisplayName": "Sparta Root Certificates",
        "PayloadIdentifier": "com.example.sparta.rootcerts",
        "PayloadRemovalDisallowed": False,
        "PayloadType": "Configuration",
        "PayloadUUID": str(uuid4()),
        "PayloadVersion": 1,
        "PayloadOrganization": "SpartaPKI",
        "PayloadDescription": "Installs multiple trusted root certificates.",
        "PayloadScope": "System"
    }
    for name, b64data in certs:
        try:
            der_data = base64.b64decode(b64data)
        except Exception as e:
            print(f"Failed to decode {name}: {e}")
            continue
        profile["PayloadContent"].append({
            "PayloadCertificateFileName": name,
            "PayloadContent": der_data,
            "PayloadDescription": "Adds a root certificate",
            "PayloadDisplayName": name,
            "PayloadIdentifier": f"com.example.cert.{name}",
            "PayloadType": "com.apple.security.root",
            "PayloadUUID": str(uuid4()),
            "PayloadVersion": 1
        })
    with open(output_path, "wb") as f:
        plistlib.dump(profile, f)
    print(f"Successfully created: {output_path}")

if __name__ == "__main__":
    script_path = "install-roots-osx.sh"
    output_file = "Sparta-Certs.mobileconfig"
    certs = extract_certificates_from_script(script_path)
    if not certs:
        print("No certificates found in the script.")
    else:
        generate_mobileconfig(certs, output_file)
EOF
                fi
                log "INFO" "Running Python script to generate Sparta-Certs.mobileconfig"
                cd "$pki_dir" || log "ERROR" "Failed to change directory to $pki_dir"
                if [[ -d "$PYTHON_VENV" ]]; then
                    "$PYTHON_VENV/bin/python" "$python_script" || log "ERROR" "Failed to generate mobileconfig file"
                else
                    python3 "$python_script" || log "ERROR" "Failed to generate mobileconfig file; ensure Python is installed"
                fi
                local mobileconfig_file="$pki_dir/Sparta-Certs.mobileconfig"
                if [[ -f "$mobileconfig_file" ]]; then
                    log "INFO" "Mobileconfig file generated at $mobileconfig_file"
                    log "INFO" "Opening the mobileconfig file for installation - requires password or TouchID once"
                    open "$mobileconfig_file" || log "WARN" "Failed to open mobileconfig file; manually open $mobileconfig_file to install"
                    echo "Follow these steps to install the Sparta Root Certificates profile:"
                    echo "1. Open 'System Settings' on your Mac."
                    echo "2. In the search bar at the top left, type 'Profiles' and select it."
                    echo "3. Locate 'Sparta Root Certificates' in the list of profiles."
                    echo "4. Double-click on 'Sparta Root Certificates' to install it."
                    echo "5. Be patient: It may take 20+ seconds for the system to respond after double-clicking."
                    local installed=$(prompt_user "Have you installed the Sparta Root Certificates profile following the steps above? (y/n)" "n")
                    if [[ "$installed" =~ ^[Yy]$ ]]; then
                        log "INFO" "User confirmed installation of root certificates profile"
                        update_summary "install_root_certificates" "PASS" "Root certificates installed via mobileconfig"
                        return 0
                    else
                        log "ERROR" "User did not install the root certificates profile"
                        update_summary "install_root_certificates" "FAIL" "Root certificates profile not installed"
                        return 1
                    fi
                else
                    log "WARN" "Mobileconfig file not found; falling back to original installation method"
                    log "INFO" "Installing root certificates - TouchID or password required multiple times"
                    cd "$pki_dir" && chmod +x install-roots-osx.sh && ./install-roots-osx.sh || log "ERROR" "Failed to install root certificates"
                    update_summary "install_root_certificates" "PASS" "Root certificates installed via original method"
                    return 0
                fi
            else
                log "WARN" "install-roots-osx.sh not found; cannot install root certificates"
                update_summary "install_root_certificates" "FAIL" "install-roots-osx.sh not found"
                return 1
            fi
        else
            log "INFO" "[DRY RUN] Would install root certificates using mobileconfig method"
            update_summary "install_root_certificates" "PASS" "[DRY RUN] Root certificates installation simulated"
            return 0
        fi
    else
        update_summary "install_root_certificates" "SKIPPED" "Root certificates already installed, skipped by user"
    fi
    return 0
}

# Configure Firefox proxy
configure_firefox_proxy() {
    local step_name="Firefox Proxy Configuration"
    log "INFO" "Providing instructions for Firefox proxy configuration"
    echo "Please configure Firefox proxy settings to use a PAC file:"
    echo "1. Open Firefox and go to Preferences -> General -> Network Settings"
    echo "2. Select 'Automatic Proxy Configuration URL' and enter: http://127.0.0.1:8081/pac"
    local configured=$(prompt_user "Have you configured the Firefox proxy as instructed? (y/n)" "n")
    if [[ "$configured" =~ ^[Yy]$ ]]; then
        log "INFO" "User confirmed Firefox proxy configuration"
        update_summary "configure_firefox_proxy" "PASS" "Firefox proxy configured by user"
    else
        log "WARN" "User did not configure Firefox proxy"
        update_summary "configure_firefox_proxy" "FAIL" "Firefox proxy not configured"
    fi
    return 0
}

# Upgrade Bash
upgrade_bash() {
    local step_name="Bash Upgrade"
    if check_and_prompt_overwrite "[[ -x \"$(brew --prefix)/bin/bash\" ]]" "$step_name"; then
        log "INFO" "Upgrading Bash via Homebrew"
        if [[ "$DRY_RUN" == false ]]; then
            brew install bash || log "ERROR" "Failed to install Bash via Homebrew"
            local brew_bash_path=$(brew --prefix)/bin/bash
            if [[ -x "$brew_bash_path" ]]; then
                local current_shell=$(dscl . -read /Users/$USER UserShell | awk '{print $2}')
                if [[ "$current_shell" == "$brew_bash_path" ]]; then
                    log "INFO" "Homebrew Bash at $brew_bash_path is already set as default shell"
                else
                    log "INFO" "Setting Bash as default shell"
                    sudo bash -c "echo $brew_bash_path >> /etc/shells" || log "WARN" "Failed to add Bash to /etc/shells"
                    chsh -s "$brew_bash_path" || log "WARN" "Failed to set Bash as default shell"
                    source "$HOME/.bash_profile"
                fi
            else
                log "ERROR" "Brew-installed Bash not found at $brew_bash_path"
                update_summary "upgrade_bash" "FAIL" "Brew-installed Bash not found"
                return 1
            fi
        else
            log "INFO" "[DRY RUN] Would upgrade Bash and set as default"
        fi
        update_summary "upgrade_bash" "PASS" "Bash upgraded and set as default"
    else
        update_summary "upgrade_bash" "SKIPPED" "Bash already upgraded, skipped by user"
    fi
    return 0
}

# Install ncpcli
install_ncpcli() {
    local step_name="ncpcli Installation"
    if check_and_prompt_overwrite "command -v ncpcli >/dev/null 2>&1" "$step_name"; then
        log "INFO" "Installing ncpcli"
        if command -v ncpcli >/dev/null 2>&1; then
            log "INFO" "ncpcli already installed and accessible in PATH"
            update_summary "install_ncpcli" "PASS" "ncpcli already installed"
            return 0
        fi
        if [[ "$DRY_RUN" == false ]]; then
            local venv_dir="$HOME/.virtualenvs/ncpcli"
            local venv_pip="$venv_dir/bin/pip"
            local venv_ncpcli="$venv_dir/bin/ncpcli"
            local symlink_path="/usr/local/bin/ncpcli"
            if [[ -d "$venv_dir" && -x "$venv_dir/bin/python" ]]; then
                log "INFO" "Virtual environment for ncpcli already exists at $venv_dir"
            else
                log "INFO" "Creating virtual environment for ncpcli at $venv_dir"
                python3 -m venv "$venv_dir" || log "ERROR" "Failed to create virtual environment at $venv_dir"
            fi
            log "INFO" "Updating pip in virtual environment"
            "$venv_pip" install -U pip || log "ERROR" "Failed to update pip in virtual environment"
            if "$venv_pip" list | grep -q "ncpcli"; then
                log "INFO" "ncpcli already installed in virtual environment"
            else
                log "INFO" "Installing ncpcli in virtual environment"
                env LDFLAGS="-L$(brew --prefix openssl@1.1)/lib" CFLAGS="-I$(brew --prefix openssl@1.1)/include" \
                "$venv_pip" install --index-url https://artifactory.oci.oraclecorp.com/api/pypi/global-release-pypi/simple \
                --trusted-host artifactory.oci.oraclecorp.com ncpcli || log "ERROR" "Failed to install ncpcli in virtual environment"
            fi
            if [[ -L "$symlink_path" && -e "$symlink_path" ]]; then
                log "INFO" "ncpcli symlink already exists at $symlink_path"
            else
                log "INFO" "Creating symlink for ncpcli at $symlink_path"
                sudo ln -s "$venv_ncpcli" "$symlink_path" || log "ERROR" "Failed to create symlink for ncpcli at $symlink_path"
            fi
        else
            log "INFO" "[DRY RUN] Would install ncpcli"
        fi
        update_summary "install_ncpcli" "PASS" "ncpcli installed"
    else
        update_summary "install_ncpcli" "SKIPPED" "ncpcli already installed, skipped by user"
    fi
    return 0
}

# Install allproxy
install_allproxy() {
    local step_name="allproxy Installation"
    if check_and_prompt_overwrite "[[ -f \"/usr/local/bin/allproxy\" ]]" "$step_name"; then
        log "INFO" "Installing allproxy"
        local allproxy_dir="$HOME/misc-tools/allproxy"
        if [[ -f "/usr/local/bin/allproxy" ]]; then
            log "INFO" "allproxy already installed"
            update_summary "install_allproxy" "PASS" "allproxy already installed"
            return 0
        fi
        if [[ "$DRY_RUN" == false ]]; then
            if [[ -d "$HOME/misc-tools/.git" ]]; then
                log "INFO" "misc-tools repository already cloned, pulling updates"
                cd "$HOME/misc-tools" && git pull || log "ERROR" "Failed to pull misc-tools updates"
            else
                log "INFO" "Cloning misc-tools repository"
                setup_ssh_key_for_bitbucket
                git clone "ssh://git@bitbucket.oci.oraclecorp.com:7999/~rralliso/misc-tools.git" "$HOME/misc-tools" || log "ERROR" "Failed to clone misc-tools repository"
            fi
            cd "$allproxy_dir" || log "ERROR" "Failed to change to allproxy directory"
            /usr/bin/python3 -m venv venv || log "ERROR" "Failed to create venv for allproxy"
            venv/bin/pip install --upgrade pip || log "ERROR" "Failed to upgrade pip in allproxy venv"
            venv/bin/pip install -e . || log "ERROR" "Failed to install allproxy in editable mode"
            venv/bin/pip install python-pkcs11 || log "ERROR" "Failed to install python-pkcs11 for allproxy"
            sudo ln -sf "$allproxy_dir/venv/bin/allproxy" /usr/local/bin/allproxy || log "ERROR" "Failed to create symlink for allproxy"
            echo "--use-pkcs11provider" >> "$allproxy_dir/allproxy/data/allproxy.conf" || log "WARN" "Failed to add pkcs11provider to allproxy.conf"
            echo "--log-color on" >> "$allproxy_dir/allproxy/data/allproxy.conf" || log "WARN" "Failed to add log-color to allproxy.conf"
        else
            log "INFO" "[DRY RUN] Would install allproxy"
        fi
        update_summary "install_allproxy" "PASS" "allproxy installed"
    else
        update_summary "install_allproxy" "SKIPPED" "allproxy already installed, skipped by user"
    fi
    return 0
}

# Install gnoc-jit-pass
install_gnoc_jit_pass() {
    local step_name="gnoc-jit-pass Installation"
    local jit_pass_dir="$TOOLS_DIR/gnoc-jit-pass"
    if check_and_prompt_overwrite "[[ -d \"$jit_pass_dir/.git\" ]]" "$step_name"; then
        log "INFO" "Installing gnoc-jit-pass"
        if [[ -d "$jit_pass_dir/.git" ]]; then
            log "INFO" "gnoc-jit-pass repository already cloned, pulling updates"
            if [[ "$DRY_RUN" == false ]]; then
                cd "$jit_pass_dir" && git pull || log "ERROR" "Failed to pull gnoc-jit-pass updates"
            fi
        else
            log "INFO" "Cloning gnoc-jit-pass repository"
            if [[ "$DRY_RUN" == false ]]; then
                setup_ssh_key_for_bitbucket
                git clone "ssh://git@bitbucket.oci.oraclecorp.com:7999/gnoc/gnoc-jit-pass.git" "$jit_pass_dir" || log "ERROR" "Failed to clone gnoc-jit-pass repository"
            else
                log "INFO" "[DRY RUN] Would clone gnoc-jit-pass repository"
            fi
        fi
        update_summary "install_gnoc_jit_pass" "PASS" "gnoc-jit-pass installed"
    else
        update_summary "install_gnoc_jit_pass" "SKIPPED" "gnoc-jit-pass already installed, skipped by user"
    fi
    return 0
}

# Install Sublime Text
install_sublime_text() {
    local step_name="Sublime Text Installation"
    if check_and_prompt_overwrite "[[ -d \"/Applications/Sublime Text.app\" ]]" "$step_name"; then
        log "INFO" "Installing Sublime Text"
        if [[ -d "/Applications/Sublime Text.app" ]]; then
            log "INFO" "Sublime Text already installed"
            update_summary "install_sublime_text" "PASS" "Sublime Text already installed"
            return 0
        fi
        if [[ "$DRY_RUN" == false ]]; then
            local open_browser=$(prompt_user "Sublime Text needs to be installed from https://www.sublimetext.com/download. Open browser to download? (y/n)" "n")
            if [[ "$open_browser" =~ ^[Yy]$ ]]; then
                open "https://www.sublimetext.com/download" || log "WARN" "Failed to open browser, download from https://www.sublimetext.com/download"
                local installed=$(prompt_user "Have you installed Sublime Text to /Applications? (y/n)" "n")
                if [[ "$installed" =~ ^[Yy]$ ]]; then
                    log "INFO" "User confirmed Sublime Text installation"
                    update_summary "install_sublime_text" "PASS" "Sublime Text installed"
                else
                    log "WARN" "User did not install Sublime Text, proceeding without installation"
                    update_summary "install_sublime_text" "FAIL" "Sublime Text not installed, continuing anyway"
                fi
            else
                log "WARN" "User declined to download Sublime Text, proceeding without installation"
                update_summary "install_sublime_text" "FAIL" "User declined to download Sublime Text, continuing anyway"
            fi
        else
            log "INFO" "[DRY RUN] Would install Sublime Text"
        fi
        update_summary "install_sublime_text" "PASS" "Sublime Text installation attempted or skipped"
    else
        update_summary "install_sublime_text" "SKIPPED" "Sublime Text already installed, skipped by user"
    fi
    return 0
}

# Install hops_cli (updated to handle existing symlinks gracefully)
install_hops_cli() {
    local step_name="hops_cli Installation"
    if check_and_prompt_overwrite "command -v hops_cli >/dev/null 2>&1" "$step_name"; then
        log "INFO" "Installing hops_cli"
        if command -v hops_cli >/dev/null 2>&1; then
            log "INFO" "hops_cli already installed and accessible in PATH"
            update_summary "install_hops_cli" "PASS" "hops_cli already installed"
        else
            if [ "$DRY_RUN" = "false" ]; then
                local venv_dir="$HOME/hops_venv"
                local venv_pip="$venv_dir/bin/pip"
                local venv_python="$venv_dir/bin/python"
                local symlink_path="/usr/local/bin/hops_cli"
                local python_version="3.13"
                local python_cmd=""
                # Check if Python 3.13 is installed
                if command -v python${python_version} >/dev/null 2>&1; then
                    python_cmd="python${python_version}"
                    log "INFO" "Python $python_version already installed"
                else
                    log "INFO" "Installing Python $python_version via Homebrew"
                    if ! brew install "python@$python_version"; then
                        log "ERROR" "Failed to install Python $python_version via Homebrew"
                        return 1
                    fi
                    python_cmd="python${python_version}"
                fi
                # Check if virtualenv is installed, install in user directory if not
                local venv_cmd=""
                if command -v virtualenv >/dev/null 2>&1; then
                    venv_cmd="virtualenv"
                    log "INFO" "Found existing virtualenv command in PATH"
                elif [ -x "$HOME/.local/bin/virtualenv" ]; then
                    venv_cmd="$HOME/.local/bin/virtualenv"
                    log "INFO" "Found virtualenv at $venv_cmd"
                else
                    log "INFO" "Installing virtualenv in user directory"
                    if ! "$python_cmd" -m pip install --user virtualenv; then
                        log "ERROR" "Failed to install virtualenv with --user"
                        return 1
                    fi
                    venv_cmd="$HOME/.local/bin/virtualenv"
                    log "INFO" "virtualenv installed to $venv_cmd"
                fi
                # Ensure the virtualenv binary exists before proceeding
                if ! [ -x "$venv_cmd" ] && ! command -v "$venv_cmd" >/dev/null 2>&1; then
                    log "WARN" "virtualenv not found at $venv_cmd, searching PATH again"
                    venv_cmd=$(command -v virtualenv 2>/dev/null || echo "")
                    if [ -z "$venv_cmd" ]; then
                        log "ERROR" "virtualenv binary not found after installation"
                        return 1
                    fi
                fi
                # Check if the virtual environment already exists
                if [ -d "$venv_dir" ] && [ -x "$venv_python" ]; then
                    log "INFO" "Virtual environment for hops_cli already exists at $venv_dir"
                else
                    log "INFO" "Creating virtual environment for hops_cli at $venv_dir using Python $python_version"
                    # Explicitly specify Python version similar to manual step
                    if ! "$venv_cmd" -p "$python_cmd" "$venv_dir"; then
                        log "ERROR" "Failed to create target virtual environment with virtualenv using $python_cmd"
                        return 1
                    fi
                fi
                # Ensure setuptools is at version 81.0.0 in the virtual environment
                log "INFO" "Checking setuptools version in virtual environment"
                local setuptools_version=""
                setuptools_version=$("$venv_pip" show setuptools 2>/dev/null | grep "^Version:" | cut -d ' ' -f 2 || echo "")
                if [ "$setuptools_version" = "81.0.0" ]; then
                    log "INFO" "setuptools already at version 81.0.0 in virtual environment"
                else
                    log "INFO" "Installing setuptools version 81.0.0 in virtual environment (current: ${setuptools_version:-not installed})"
                    if ! "$venv_pip" install setuptools==81.0.0; then
                        log "ERROR" "Failed to install setuptools version 81.0.0 in virtual environment"
                        return 1
                    fi
                fi
                # Install hops-cli in the virtual environment
                log "INFO" "Installing hops-cli in virtual environment"
                if "$venv_pip" list 2>/dev/null | grep "hops-cli" >/dev/null 2>&1; then
                    log "INFO" "hops-cli already installed in virtual environment"
                else
                    if ! "$venv_pip" install --default-timeout=100 -U --index-url https://artifactory.oci.oraclecorp.com/api/pypi/global-release-pypi/simple hops-cli; then
                        log "ERROR" "Failed to install hops-cli in virtual environment"
                        return 1
                    fi
                fi
                # Check if symlink for hops_cli already exists and handle accordingly
                if [ -L "$symlink_path" ]; then
                    log "INFO" "Symlink already exists at $symlink_path, checking if it needs updating"
                    current_target=$(readlink "$symlink_path" 2>/dev/null || echo "")
                    expected_target="$venv_dir/bin/hops_cli"
                    if [ "$current_target" = "$expected_target" ] && [ -e "$symlink_path" ]; then
                        log "INFO" "Symlink at $symlink_path is correct and points to $expected_target"
                    else
                        log "INFO" "Updating symlink at $symlink_path (current target: ${current_target:-broken})"
                        if ! sudo rm -f "$symlink_path" 2>/dev/null; then
                            log "WARN" "Failed to remove existing symlink at $symlink_path, attempting to overwrite"
                        fi
                        if ! sudo ln -sf "$expected_target" "$symlink_path"; then
                            log "ERROR" "Failed to update symlink at $symlink_path to point to $expected_target"
                            return 1
                        fi
                        log "INFO" "Symlink updated successfully at $symlink_path"
                    fi
                else
                    log "INFO" "Creating symlink for hops_cli at $symlink_path"
                    if ! sudo ln -s "$venv_dir/bin/hops_cli" "$symlink_path"; then
                        log "ERROR" "Failed to create symlink for hops_cli at $symlink_path"
                        return 1
                    fi
                fi
                log "INFO" "hops_cli installation completed"
            else
                log "INFO" "[DRY RUN] Would install hops_cli"
            fi
            update_summary "install_hops_cli" "PASS" "hops_cli installed"
        fi
    else
        update_summary "install_hops_cli" "SKIPPED" "hops_cli already installed, skipped by user"
    fi
    return 0
}

# Configure shell profiles
configure_shell_profiles() {
    local step_name="Shell Profiles Configuration"
    log "INFO" "Configuring shell profiles .bash_profile, .zshrc"
    local profiles=("$HOME/.bash_profile" "$HOME/.zshrc")
    local config_lines=(
        "alias ll='ls -lAh'"
        "alias rm='rm -i'"
        "alias subl=\"/Applications/Sublime\ Text.app/Contents/SharedSupport/bin/subl\""
        "export CLICOLOR=1"
        "export LSCOLORS=ExGxBxDxCxEgEdxbxgxcxd"
        "HISTSIZE=5000"
        "PS1=\"[\\\[\e[1;34m\\\]\D{%D}\\\[\e[m\\\] \\\[\e[1;92m\\\]\t\\\[\e[m\\\] \\\[\e[1;90m\\\]\u\\\[\e[m\\\]\\\[\e[1;37m\\\]@\\\[\e[m\\\]\\\[\e[1;33m\\\]\h\\\[\e[m\\\]:\\\[\e[1;36m\\\]\W\\\[\e[m\\\]]\\\[\e[91m\\\]\\\\$\\\[\e[m\\\] \""
    )
    for profile in "${profiles[@]}"; do
        if [[ -f "$profile" ]] || [[ "$DRY_RUN" == false ]]; then
            log "INFO" "Updating $profile"
            if [[ "$DRY_RUN" == false ]]; then
                for line in "${config_lines[@]}"; do
                    if ! grep -qF "$line" "$profile" 2>/dev/null; then
                        echo "$line" >> "$profile" || log "WARN" "Failed to append line to $profile"
                    fi
                done
            else
                log "INFO" "[DRY RUN] Would update $profile"
            fi
        fi
    done
    update_summary "configure_shell_profiles" "PASS" "Shell profiles configured"
    return 0
}

prompt_for_input() {
    local prompt="$1"
    local var_name="$2"
    local input=""
    while true; do
        read -p "$prompt: " input
        if [[ -z "$input" ]]; then
            echo "Input cannot be empty, please try again."
            continue
        fi
        read -p "Confirm $prompt (re-enter to verify): " confirm
        if [[ "$input" == "$confirm" ]]; then
            eval "$var_name='$input'"
            break
        else
            echo "Entries do not match, please try again."
        fi
    done
}

setup_sparta_roots() {
    log "INFO" "Setting up Sparta roots for hops-cli"
    local roots_dir="$HOME/sparta_roots"
    local source_dir="$HOME/sparta-pki/trustroots"
    
    if [[ ! -d "$source_dir" ]]; then
        log "ERROR" "sparta-pki/trustroots directory not found. Ensure sparta-pki is cloned."
        update_summary "setup_sparta_roots" "FAIL" "sparta-pki/trustroots not found"
        return 1
    fi

    if [[ -d "$roots_dir" ]]; then
        log "INFO" "Sparta roots directory already exists at $roots_dir"
        prompt_overwrite "Sparta roots directory" || { update_summary "setup_sparta_roots" "PASS" "Sparta roots directory already exists, skipped overwrite"; return 0; }
        log "INFO" "Removing existing Sparta roots directory for reinstall"
        [[ "$DRY_RUN" == false ]] && rm -rf "$roots_dir" 2>/dev/null || log "INFO" "[DRY RUN] Would remove existing Sparta roots directory"
    fi

    if [[ "$DRY_RUN" == false ]]; then
        log "INFO" "Creating Sparta roots directory at $roots_dir"
        mkdir -p "$roots_dir" || log "ERROR" "Failed to create directory at $roots_dir"
        log "INFO" "Copying trustroots files from $source_dir to $roots_dir"
        cp "$source_dir/"* "$roots_dir/" 2>/dev/null || log "ERROR" "Failed to copy trustroots files to $roots_dir"
    else
        log "INFO" "[DRY RUN] Would create $roots_dir and copy trustroots files from $source_dir"
    fi
    update_summary "setup_sparta_roots" "PASS" "Sparta roots set up for hops-cli"
    return 0
}

configure_hops_cli() {
    log "INFO" "Configuring hops-cli"
    read -p "Would you like to configure hops-cli now? (y/n): " configure_now
    if [[ "$configure_now" =~ ^[Yy]$ ]]; then
        log "INFO" "User chose to configure hops-cli"
        # Launch allproxy in a new terminal window for YubiKey PIN interaction
        if command -v allproxy >/dev/null 2>&1; then
            log "INFO" "Launching allproxy in a new terminal window for YubiKey PIN input"
            if [[ "$DRY_RUN" == false ]]; then
                # Use osascript to open a new Terminal window and run allproxy
                osascript -e 'tell application "Terminal" to do script "allproxy"' >/dev/null 2>&1 || {
                    log "WARN" "Failed to open new terminal window for allproxy; launching in background as fallback"
                    allproxy >/dev/null 2>&1 &
                    local allproxy_pid=$!
                    log "INFO" "allproxy started with PID $allproxy_pid as fallback, but PIN input may not be possible"
                }
                echo "A new terminal window has opened for allproxy. Please enter your YubiKey PIN if prompted."
                read -p "Have you entered the YubiKey PIN for allproxy and is it running? (y/n): " allproxy_running
                if [[ "$allproxy_running" =~ ^[Yy]$ ]]; then
                    log "INFO" "User confirmed allproxy is running with YubiKey PIN"
                else
                    log "WARN" "User did not confirm allproxy is running; proceeding but hops-cli configuration may fail"
                fi
            else
                log "INFO" "[DRY RUN] Would launch allproxy in a new terminal window"
            fi
        else
            log "WARN" "allproxy not found in PATH, proceeding without launching it"
        fi
        echo "A browser will open to a permissions page. Please save the page after it loads."
        # If GUID is not set, prompt for it
        if [[ -z "$GUID" ]]; then
            prompt_for_input "Enter your GUID" "GUID"
        fi
        local permissions_url="https://permissions.oci.oraclecorp.com/api/v1/accounts/$GUID"
        log "INFO" "Opening browser to $permissions_url"
        if [[ "$DRY_RUN" == false ]]; then
            open "$permissions_url" || log "WARN" "Failed to open browser, manually visit $permissions_url and save the page"
            read -p "Have you saved the permissions page from the browser? (y/n): " page_saved
            if [[ "$page_saved" =~ ^[Yy]$ ]]; then
                log "INFO" "User confirmed permissions page is saved"
                log "INFO" "Running hops-cli configuration for user $GUID"
                ( source $HOME/hops_venv/bin/activate && hops-cli --user "$GUID" ) || log "ERROR" "Failed to run hops-cli --user $GUID"
                update_summary "configure_hops_cli" "PASS" "hops-cli configured for user $GUID"
            else
                log "WARN" "User did not save permissions page, skipping hops-cli configuration"
                update_summary "configure_hops_cli" "FAIL" "Permissions page not saved, hops-cli not configured"
            fi
        else
            log "INFO" "[DRY RUN] Would open browser to $permissions_url and run hops-cli --user $GUID"
            update_summary "configure_hops_cli" "PASS" "[DRY RUN] hops-cli configuration simulated"
        fi
    else
        log "INFO" "User chose not to configure hops-cli now"
        update_summary "configure_hops_cli" "PASS" "hops-cli configuration skipped by user"
    fi
    return 0
}

# Recommend manual apps
recommend_manual_apps() {
    local step_name="Manual App Recommendations"
    log "INFO" "Recommending manual installation of Amphetamine and Rectangle"
    echo "Please install the following apps manually:"
    echo "- Amphetamine: https://apps.apple.com/us/app/amphetamine/id937984704"
    echo "- Rectangle: https://rectangleapp.com/"
    local noted=$(prompt_user "Have you noted these recommendations? (y/n)" "n")
    if [[ "$noted" =~ ^[Yy]$ ]]; then
        log "INFO" "User noted manual app recommendations"
    else
        log "WARN" "User did not note manual app recommendations"
    fi
    update_summary "recommend_manual_apps" "PASS" "Manual app recommendations provided"
    return 0
}

# Confirm VPN disconnect and Firefox installation
confirm_vpn_disconnect() {
    local step_name="VPN Disconnect and Firefox Installation Confirmation"
    log "INFO" "Step 0: Initial setup checks for onboarding"
    log "INFO" "Checking if Firefox is installed"
    local firefox_installed=$(prompt_user "Have you installed Firefox on your system? (y/n)" "n")
    if [[ "$firefox_installed" =~ ^[Yy]$ ]]; then
        log "INFO" "User confirmed Firefox is installed"
        update_summary "confirm_firefox_installation" "PASS" "Firefox already installed"
    else
        log "WARN" "User has not installed Firefox"
        log "INFO" "Please download and install Firefox from the Endpoint Management Platform (EMP) application on your Mac."
        echo "Open the EMP application to download Firefox. If you need assistance, refer to internal documentation or support."
        local firefox_downloaded=$(prompt_user "Have you downloaded and installed Firefox using EMP? (y/n)" "n")
        if [[ "$firefox_downloaded" =~ ^[Yy]$ ]]; then
            log "INFO" "User confirmed Firefox installation after download via EMP"
            update_summary "confirm_firefox_installation" "PASS" "Firefox installed after download via EMP"
        else
            log "ERROR" "User has not installed Firefox. Please install Firefox using EMP before proceeding."
            update_summary "confirm_firefox_installation" "FAIL" "Firefox not installed, script aborted"
            exit 1
        fi
    fi
    log "INFO" "Confirming VPN disconnection before onboarding"
    local disconnected=$(prompt_user "Have you disconnected from any VPN before starting the onboarding process? (y/n)" "n")
    if [[ "$disconnected" =~ ^[Yy]$ ]]; then
        log "INFO" "User confirmed VPN is disconnected"
        update_summary "confirm_vpn_disconnect" "PASS" "VPN disconnection confirmed"
    else
        log "ERROR" "User has not disconnected from VPN. Please disconnect and rerun the script."
        update_summary "confirm_vpn_disconnect" "FAIL" "VPN not disconnected, script aborted"
        exit 1
    fi
    return 0
}

# Main function
main() {
    parse_args "$@"
    log "INFO" "Starting OCI data center employee onboarding script - Dry Run: $DRY_RUN, Interactive: $INTERACTIVE"

    log "INFO" "Step 0: Confirming VPN Disconnection and Firefox Installation"
    confirm_vpn_disconnect

    log "INFO" "Step 1: Installing Xcode Command Line Tools"
    install_xcode_tools

    log "INFO" "Step 2: Installing Homebrew"
    install_homebrew

    log "INFO" "Step 3: Installing jq"
    install_jq

    log "INFO" "Step 4: Installing OpenSC"
    install_opensc

    log "INFO" "Step 5: Installing YubiSwitch"
    install_yubiswitch

    log "INFO" "Step 6: Validating YubiKey Configuration"
    validate_yubikey_config

    log "INFO" "Step 7: Installing iTerm2"
    install_iterm2

    log "INFO" "Step 8: Enabling TouchID for iTerm2"
    enable_touchid_iterm2

    log "INFO" "Step 9: Setting up SSH Configuration"
    setup_ssh_config

    log "INFO" "Step 10: Installing Root Certificates"
    install_root_certificates

    log "INFO" "Step 11: Setup Sparta Roots dependency"
    setup_sparta_roots

    log "INFO" "Step 12: Configuring Firefox Proxy - Manual"
    configure_firefox_proxy

    log "INFO" "Step 13: Configuring Shell Profile"
    configure_shell_profiles

    log "INFO" "Step 14: Upgrading Bash"
    upgrade_bash

    log "INFO" "Step 15: Installing ncpcli"
    install_ncpcli

    log "INFO" "Step 16: Installing allproxy"
    install_allproxy

    log "INFO" "Step 17: Installing hops_cli"
    install_hops_cli

    log "INFO" "Step 18 skipped: Cloning phx-gov-tools"
    # clone_python_scripts

    log "INFO" "Step 19: Installing Python Virtual Environment"
    install_python_venv

    log "INFO" "Step 20: Installing gnoc-jit-pass"
    install_gnoc_jit_pass

    log "INFO" "Step 21: Installing Sublime Text"
    install_sublime_text

    log "INFO" "Step 22: Recommending Manual Apps"
    recommend_manual_apps

    log "INFO" "Step 22: Configuring HOPS CLI"
    configure_hops_cli

    log "INFO" "Onboarding completed successfully"
}

# Traps for error handling and summary output
trap 'log "ERROR" "Error on line $LINENO"' ERR
trap 'log "INFO" "Script completed"; if command -v jq >/dev/null 2>&1; then echo "$SUMMARY_JSON" | jq . > "$JSON_SUMMARY_FILE"; echo "$SUMMARY_JSON" | jq .; else echo "$SUMMARY_JSON" > "$JSON_SUMMARY_FILE"; echo "$SUMMARY_JSON"; fi' EXIT

# Execute main
main "$@"