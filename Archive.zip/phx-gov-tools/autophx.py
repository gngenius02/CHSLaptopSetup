#!/chs-gov-tools/bin/python3
"""
PHX-Gov DO Ticket Triage Script
For updates and support, refer to:
https://confluence.oraclecorp.com/confluence/display/~jesse.boydston@oracle.com/PHX-Gov+DO+Ticket+Triage+Scripts
This script automates ticket triage in JIRA for DO tickets, integrating with StoreKeeper for asset data.
"""

import os
import sys
import json
import subprocess
from typing import List, Dict, Any
import requests
from requests.auth import HTTPBasicAuth
from jira import JIRA

# Constants
JIRA_SERVER = "https://jira-sd.mc1.oracleiaas.com"
STOREKEEPER_URL_TEMPLATE = "https://storekeeper.oci.oraclecorp.com/v1/assets/{}"
VALID_STATUSES = {"In Progress", "Pending", "Pending Customer", "Pending Part(s)", "Pending Engineering"}
TICKET_FORMAT_PREFIX = "DO-"
BULK_MODE_KEYWORD = "bulk"


def get_credentials() -> tuple[str, str]:
    """Retrieve JIRA credentials from environment and system keychain."""
    username = os.environ.get("JIRA_USER")
    if not username:
        raise ValueError("JIRA_USER environment variable not set.  Please setup stencil.")
    
    token_cmd = 'security find-generic-password -ga iad 2>&1 | grep "password:" | cut -d\\" -f2'
    try:
        token = subprocess.check_output(token_cmd, shell=True, text=True).strip()
    except subprocess.CalledProcessError as e:
        raise RuntimeError("Failed to retrieve JIRA token from keychain.") from e
    return username, token


def storekeeper_lookup(serial: str) -> Dict[str, Any]:
    """Fetch asset data from StoreKeeper API by serial number."""
    url = STOREKEEPER_URL_TEMPLATE.format(serial)
    try:
        response = requests.get(url, timeout=10)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as err:
        print(f"StoreKeeper API Error: {err}")
        sys.exit(1)


def fetch_jira_attachment(url: str, username: str, token: str) -> Dict[str, Any]:
    """Retrieve attachment data from JIRA."""
    try:
        response = requests.get(url, auth=HTTPBasicAuth(username, token), timeout=10)
        response.raise_for_status()
        return response.json()
    except requests.exceptions.RequestException as e:
        raise requests.exceptions.HTTPError(f"Failed to fetch JIRA attachment: {e}")


def match_metadata(find_value: str, metadata: List[Dict], match_name: str, prompt: str = None) -> str:
    """Match a value in metadata, case-insensitive, with optional user prompt for retry."""
    find_value_lower = find_value.lower()
    for item in metadata:
        value_lower = item["value"].lower()
        if value_lower == find_value_lower or value_lower.startswith(find_value_lower):
            return item["value"]
    if prompt:
        new_value = input(prompt)
        if new_value:
            return match_metadata(new_value, metadata, match_name, prompt)
    return ""


def process_bulk_tickets(username: str, token: str) -> None:
    """Handle multiple tickets in bulk mode."""
    bulk_list = []
    print("Enter ticket numbers (press Enter without input to finish):")
    while True:
        next_entry = input().strip()
        if not next_entry:
            break
        bulk_list.append(next_entry)
    for entry in bulk_list:
        print(f"Working on {entry}")
        process_ticket(entry, username, token)


def generate_link_labels(issue: Any, attachment_data: Dict) -> str:
    """Generate formatted link labels for JIRA comment."""
    device_a_label = (
        f"{attachment_data['device']} {attachment_data['interface'].replace('Ethernet', 'eth')}\n"
        f"Rack {attachment_data['rack']} U{attachment_data['elevation']}"
    )
    device_b_label = (
        f"{attachment_data['remote_device']} {attachment_data['remote_interface'].replace('Ethernet', 'eth')}\n"
        f"Rack {attachment_data['remote_rack']} U{attachment_data['remote_elevation']}"
    )
    return (
        f"{str(issue)}\n"
        f"Label 1:\n{{code:java}}\n{device_a_label}\n{device_b_label}\n{{code}}\n"
        f"Label 2:\n{{code:java}}\n{device_b_label}\n{device_a_label}\n{{code}}"
    )


def process_ticket(ticket: str, username: str, token: str) -> None:
    """Main logic to process a single JIRA ticket."""
    if TICKET_FORMAT_PREFIX not in ticket:
        print(f"Invalid ticket format. Please use {TICKET_FORMAT_PREFIX}XXXXXX.")
        sys.exit(1)

    try:
        jira = JIRA(server=JIRA_SERVER, basic_auth=(username, token))
    except Exception as e:
        print("Stored IAD JIT Password is invalid, please run 'jit-pass iad'")
        sys.exit(1)

    try:
        issue = jira.issue(ticket)
        status = str(issue.fields.status)
        serial = issue.fields.customfield_10104.split()[-1]
        summary = issue.fields.summary
        meta = jira.editmeta(issue)

        # Process attachments if available
        configfile = False
        for attachment in issue.fields.attachment:
            if str(attachment) == "config.json":
                configfile = True
                attachment_data = fetch_jira_attachment(attachment.content, username, token)
                link_labels = generate_link_labels(issue, attachment_data)
                jira.add_comment(issue, link_labels)
                print("Link down - Labels generated from config.json and attached.")

        # Fetch asset data from StoreKeeper
        asset_data = storekeeper_lookup(serial)
        canonical_ad = match_metadata(
            asset_data["availability_domain_room"]["availability_domain_canonical_short_code"],
            meta["fields"]["customfield_12605"]["allowedValues"],
            "Canonical AD"
        )
        building = match_metadata(
            asset_data["availability_domain_room"]["building_canonical_name"],
            meta["fields"]["customfield_12604"]["allowedValues"],
            "Building"
        )
        region = match_metadata(
            building,
            meta["fields"]["customfield_10108"]["allowedValues"],
            "Region"
        )

        # Prepare custom fields for update
        custom_fields = {
            "customfield_10108": {"value": region},
            "customfield_12604": {"value": building},
            "customfield_10104": serial,
            "summary": summary
        }
        # Filter out fields where the 'value' key exists and is empty
        filtered_fields = {}
        for key, value in custom_fields.items():
            if isinstance(value, dict) and "value" in value and value["value"] == "":
                continue
            filtered_fields[key] = value

        # Update ticket status if needed
        if status in VALID_STATUSES:
            print(f"Ticket is already {status}. No change to status has been made.")
        else:
            comment = "Set to Pending. No performer is yet assigned. This will be worked in order of severity."
            jira.transition_issue(ticket, transition="31", comment=comment)
            print(f"Ticket set to Pending from {status}.")

        issue.update(fields=filtered_fields)
    except Exception as e:
        print(f"Error processing ticket {ticket}: {str(e)}")


def main() -> None:
    """Entry point for the script."""
    try:
        username, token = get_credentials()
        if len(sys.argv) > 1:
            ticket = sys.argv[1]
            if BULK_MODE_KEYWORD in ticket.lower():
                process_bulk_tickets(username, token)
            else:
                process_ticket(ticket, username, token)
        else:
            print("Please enter a ticket number.")
            sys.exit(1)
    except Exception as e:
        print(f"Script execution failed: {str(e)}")
        sys.exit(1)


if __name__ == "__main__":
    main()