package main

import _ "embed"

//go:embed iterm2.plist
var iterm2Plist []byte
