package main

import (
	"fmt"
	"os"
	"os/exec"
	"strings"
)

// preflightRun executes all preflight checks. Returns the Oracle GUID entered by the user.
func preflightRun() (string, error) {
	logSetPhase("preflight")

	if err := preflightNetCheck(); err != nil {
		return "", err
	}
	if err := preflightSSHKey(); err != nil {
		return "", err
	}
	return preflightIdentity()
}

func preflightNetCheck() error {
	logInfo("net_check", "checking public internet reachability", nil)
	if err := exec.Command("ping", "-c", "1", "-W", "3000", "github.com").Run(); err != nil {
		return fmt.Errorf("public internet unreachable — ensure VPN is OFF before running Phase 1")
	}
	logInfo("net_check", "public internet reachable", nil)
	return nil
}

func preflightSSHKey() error {
	home := os.Getenv("HOME")
	candidates := []string{
		home + "/.ssh/id_ed25519.pub",
		home + "/.ssh/id_rsa.pub",
	}

	var pubKeyPath string
	for _, p := range candidates {
		if pathExists(p) {
			pubKeyPath = p
			break
		}
	}

	if pubKeyPath == "" {
		logInfo("ssh_key", "no SSH key found, generating ed25519 key", nil)
		email, err := uiPrompt("SSH Key Setup", "Enter your Oracle email for SSH key generation:", "firstname.lastname@oracle.com")
		if err != nil {
			return fmt.Errorf("SSH key generation cancelled: %w", err)
		}
		keyPath := home + "/.ssh/id_ed25519"
		if err := exec.Command("ssh-keygen", "-t", "ed25519", "-C", email, "-f", keyPath, "-N", "").Run(); err != nil {
			return fmt.Errorf("ssh-keygen failed: %w", err)
		}
		pubKeyPath = keyPath + ".pub"
		logInfo("ssh_key", "SSH key generated", map[string]string{"path": keyPath})
	}

	pubKey, err := os.ReadFile(pubKeyPath)
	if err != nil {
		return fmt.Errorf("could not read public key at %s: %w", pubKeyPath, err)
	}

	logInfo("ssh_key", "presenting SSH public key to user", nil)
	return uiShowSSHKey(strings.TrimSpace(string(pubKey)))
}

func preflightIdentity() (string, error) {
	guid, err := uiPrompt("Oracle Identity", "Enter your Oracle GUID (e.g. jsmith):", "")
	if err != nil || strings.TrimSpace(guid) == "" {
		return "", fmt.Errorf("oracle GUID is required")
	}
	guid = strings.TrimSpace(guid)
	logInfo("identity", "oracle GUID entered", map[string]string{"guid": guid})

	hostname := cmdOutput("scutil", "--get", "LocalHostName")
	logInfo("identity", "current hostname", map[string]string{"hostname": hostname})

	if strings.EqualFold(hostname, guid) || strings.EqualFold(hostname, guid+"-mac") {
		logInfo("identity", "hostname matches GUID, no rename needed", nil)
		return guid, nil
	}

	logWarn("identity", "hostname mismatch, renaming", map[string]string{
		"current": hostname, "guid": guid,
	})
	_ = uiAlert("Hostname Mismatch",
		fmt.Sprintf("Hostname (%s) does not match GUID (%s).\n\nThe tool will rename your Mac. You MUST log out and back in after this step.", hostname, guid))

	cmds := [][]string{
		{"scutil", "--set", "ComputerName", guid},
		{"scutil", "--set", "LocalHostName", guid},
		{"scutil", "--set", "HostName", guid + ".local"},
		{"dscl", ".", "-change", "/Users/" + os.Getenv("USER"), "RealName", os.Getenv("USER"), guid},
	}
	for _, c := range cmds {
		if _, err := sudoCmd("identity_rename", nil, c[0], c[1:]...); err != nil {
			return "", fmt.Errorf("rename command failed (%s): %w", strings.Join(c, " "), err)
		}
	}

	logInfo("identity", "rename complete — requiring relogin", nil)
	_ = uiAlert("Relogin Required", "Hostname updated.\n\nPlease LOG OUT and log back in, then re-run chs-onboard.")
	os.Exit(0)
	return guid, nil
}
